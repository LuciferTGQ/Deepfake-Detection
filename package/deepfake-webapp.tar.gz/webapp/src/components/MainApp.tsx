import React, { useState } from 'react'
import { ArrowLeft, Shield } from 'lucide-react'
import UploadZone from './UploadZone'
import ProgressBar from './ProgressBar'
import ResultDisplay from './ResultDisplay'

const MainApp: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [analysisResult, setAnalysisResult] = useState<{
    confidence: number
    status: 'very-trusted' | 'trusted' | 'untrusted'
    message: string
  } | null>(null)

  const handleFileSelect = (file: File) => {
    setSelectedFile(file)
    setAnalysisResult(null)
    setAnalysisProgress(0)
  }

  const handleStartAnalysis = async () => {
    if (!selectedFile) return

    setIsAnalyzing(true)
    setAnalysisProgress(0)

    // 模拟分析过程
    const interval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          // 模拟分析结果
          const mockResult = {
            confidence: Math.floor(Math.random() * 30) + 70, // 70-100%
            status: Math.random() > 0.3 ? 'very-trusted' : 'trusted' as const,
            message: '视频内容检测完成，未发现明显的AI换脸痕迹'
          }
          setAnalysisResult(mockResult)
          setIsAnalyzing(false)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 500)
  }

  const handleBackToWelcome = () => {
    window.location.reload()
  }

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-4xl mx-auto">
        {/* 顶部导航 */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={handleBackToWelcome}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>返回</span>
          </button>
          
          <div className="flex items-center space-x-3">
            <Shield className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
              智能检测AI换脸
            </h1>
          </div>
          
          <div className="w-20"></div> {/* 占位符保持居中 */}
        </div>

        {/* 主要内容区域 */}
        <div className="bg-white/40 backdrop-blur-xl border border-white/30 rounded-3xl p-8 md:p-12 shadow-2xl">
          
          {!analysisResult ? (
            <>
              {/* 上传区域 */}
              <div className="mb-8">
                <UploadZone
                  onFileSelect={handleFileSelect}
                  selectedFile={selectedFile}
                  disabled={isAnalyzing}
                />
              </div>

              {/* 分析按钮 */}
              <div className="text-center mb-8">
                <button
                  onClick={handleStartAnalysis}
                  disabled={!selectedFile || isAnalyzing}
                  className={`py-4 px-12 rounded-2xl font-semibold text-lg transition-all duration-300 ${
                    selectedFile && !isAnalyzing
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {isAnalyzing ? '分析中...' : '开始分析'}
                </button>
              </div>

              {/* 进度条 */}
              {isAnalyzing && (
                <div className="mb-8">
                  <ProgressBar progress={analysisProgress} />
                </div>
              )}
            </>
          ) : (
            /* 结果展示 */
            <ResultDisplay result={analysisResult} />
          )}
        </div>

        {/* 底部提示 */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>支持格式：MP4、AVI、MOV、MKV | 最大文件：500MB</p>
        </div>
      </div>
    </div>
  )
}

export default MainApp